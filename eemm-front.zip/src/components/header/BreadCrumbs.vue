<template>
  <ods-breadcrumb separator="/">
    <ods-breadcrumb-item :to="{ path: '/' }">Dashboard</ods-breadcrumb-item>
    <ods-breadcrumb-item><a href="/">Another Page</a></ods-breadcrumb-item>
  </ods-breadcrumb>
</template>
