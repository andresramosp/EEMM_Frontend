import { ref, onMounted } from 'vue'
import type { RouteLocationNormalized } from 'vue-router'
import { useMenuStore } from '@/stores/menu'

export interface NavigationItem {
  id: string | number
  langs: {
    es: string
    en: string
  }
  icon?: string
  disabled?: boolean
  notifications?: number
  children?: Record<string, NavigationItem>
  to?: string
  active?: boolean
}

interface NavigationData {
  [key: string]: NavigationItem
}
// Versión tansformada del menú para compatibilidad con ODS+
const navigation = ref({})

export const useNavManager = () => {
  const menuStore = useMenuStore()
  const loading = ref(false)

  const fetchMenuItems = async () => {
    if (!Object.keys(menuStore.menuItems).length) {
      loading.value = true
      await menuStore.getMenuItems()
      navigation.value = transformMenu(menuStore.menuItems)
      loading.value = false
    }
  }

  const setCurrentItem = (route: RouteLocationNormalized) => {
    const nestedItems = (nestedData: NavigationData) => {
      for (const key of Object.keys(nestedData)) {
        const item = nestedData[key]
        item.active =
          route.name === item.id || route.matched.some((record) => record.name === item.id)
        if (item.children) {
          nestedItems(item.children)
        }
      }
    }

    const newNavigation = { ...navigation.value }
    !!newNavigation && nestedItems(newNavigation)
    navigation.value = { ...newNavigation }
  }

  onMounted(() => {
    fetchMenuItems()
  })

  return {
    navigation,
    setCurrentItem,
    fetchMenuItems,
    loading,
  }
}

const transformMenu = (items: any[]): NavigationData => {
  const transform = (item: any): any => {
    const navItem: any = {
      id: item.idMenu,
      langs: {
        es: item.title,
        en: item.title.replace(/_/g, ' ').replace(/\b\w/g, (l: string) => l.toUpperCase()),
      },
      icon: item.icon || 'menu',
      to: item.linkMethod ? `#/${item.linkMethod}` : undefined,
      children: {},
    }

    if (Array.isArray(item.childs) && item.childs.length > 0) {
      item.childs.forEach((child: any) => {
        const transformed = transform(child)
        navItem.children[transformed.langs.es] = transformed
      })
    }

    return navItem
  }

  const result: Record<string, any> = {}
  items.forEach((item: any) => {
    const transformed = transform(item)
    result[transformed.langs.es] = transformed
  })
  return result
}
