// stores/menuStore.ts
import { defineStore } from 'pinia'
import { ref } from 'vue'
import navigationConfig from '../assets/navigation_backend.json'

export const useMenuStore = defineStore('menu', () => {
  // Versión original del menú traído desde backend
  const menuItems = ref<any[]>([])

  const getMenuItems = async () => {
    return new Promise<void>((resolve) => {
      setTimeout(() => {
        setMenuItems(navigationConfig.data)
        resolve()
      }, 500)
    })
  }

  const setMenuItems = (items: any) => {
    menuItems.value = items
  }

  return {
    menuItems,
    setMenuItems,
    getMenuItems,
  }
})
