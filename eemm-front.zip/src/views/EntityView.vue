<template>Pantalla Entidad</template>

<script lang="ts" setup></script>
