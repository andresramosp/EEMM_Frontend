<template>Pantalla Dashboard</template>

<script lang="ts" setup></script>
