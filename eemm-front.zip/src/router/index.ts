import { createRouter, createWebHistory, type RouteLocationNormalized } from 'vue-router'
import DashboardView from '../views/DashboardView.vue'
import { useNavManager } from '@/composables/useNavManager'
import EntityView from '@/views/EntityView.vue'

const router = createRouter({
  history: createWebHistory(import.meta.env.BASE_URL),
  routes: [
    {
      path: '/',
      name: 'dashboard',
      component: DashboardView,
    },
    {
      path: '/entity',
      name: 'entity',
      component: EntityView,
    },
  ],
})

router.beforeEach((to, from, next) => {
  useNavManager().setCurrentItem(to)
  next()
})

export default router
